package com.capgemini.jackson.json.demo;

import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Driver {

	public static void main(String[] args) {
		try {
			//create object mapper
			ObjectMapper mapper= new ObjectMapper();
			
			//create Json file and map/convert to java POJO
			//data/sample-lite.json
			Student theStudent= mapper.readValue( new File("data/sample-full.json"), Student.class);
			
			//print firstname and lastname
			System.out.println("fisrtname= "+ theStudent.getFirstName());
			System.out.println("Lastname= " + theStudent.getLastName());
			
			//print out address: street and city
			Address tempaddress= theStudent.getAddress();
			System.out.println("street= " + tempaddress.getStreet());
			System.out.println("city= " + tempaddress.getCity());
			
			//print out language
			for(String tempLang: theStudent.getLanguages()) {
				System.out.println(tempLang);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	

	}
}
